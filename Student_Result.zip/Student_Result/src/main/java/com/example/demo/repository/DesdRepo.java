package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.Desd;

public interface DesdRepo extends JpaRepository<Desd,Integer> {

}
