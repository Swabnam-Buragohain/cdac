package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Dac;
import com.example.demo.entity.Desd;
import com.example.demo.repository.DacRepo;
import com.example.demo.repository.DesdRepo;

@Service
public class DesdServiceImpl implements DesdService {

	@Autowired
	private DesdRepo repo;
	
	
	@Override
	public Desd saveStudent(Desd desd) {
		return repo.save(desd);
	}

	@Override
	public List<Desd> getAllStudent() {		
		return repo.findAll();
}

	@Override
	public Desd getStudentById(Integer id) {
		return repo.findById(id).get();

	}

	@Override
	public String deleteStudent(Integer id) {
		
			repo.deleteById(id);

		return (id +" is deleted successfully");
	}

	@Override
	public Desd editStudent(Desd desd) {
		
		return repo.save(desd);
	}

}
