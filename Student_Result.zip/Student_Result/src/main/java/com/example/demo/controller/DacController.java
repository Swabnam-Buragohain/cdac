package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Dac;
import com.example.demo.repository.DacRepo;
import com.example.demo.service.DacService;

@CrossOrigin("*")
@RequestMapping("/Dac")
@RestController
public class DacController {

	
	@Autowired
	private DacService service;
	
	@Autowired
	DacRepo repo;

	@PostMapping("/saveStudent")
	public ResponseEntity<?> saveStudent(@RequestBody Dac dac) {
		return new ResponseEntity<>(service.saveStudent(dac), HttpStatus.CREATED);
	}

	@GetMapping("/all")
	public ResponseEntity<?> getAllStudent() {
		return new ResponseEntity<>(service.getAllStudent(), HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<?> getStudentById(@PathVariable Integer id) {
		return new ResponseEntity<>(service.getStudentById(id), HttpStatus.OK);
	}

//	@GetMapping("/deleteProduct/{id}")
//	public ResponseEntity<?> deleteStudent(@PathVariable Integer id) {
//		return new ResponseEntity<>(service.deleteStudent(id), HttpStatus.OK);
//	}
	
	@DeleteMapping("delete/{id}")
	public ResponseEntity<?> deleteProduct(@PathVariable int id)
	{
		
		return new ResponseEntity<>(service.deleteStudent(id), HttpStatus.OK);
	}
	
//	@PostMapping("/editStudent")
//	public ResponseEntity<?> editStudent(@RequestBody Dac dac) {
//		return new ResponseEntity<>(service.editStudent(dac), HttpStatus.CREATED);
//	}
	
	@PutMapping("/update")
	public ResponseEntity<?>  editStudent(@RequestBody Dac dac)
	{
		return new ResponseEntity<>(service.editStudent(dac), HttpStatus.CREATED);
		
	}
}
