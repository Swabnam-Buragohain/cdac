package com.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

@Entity
@Table(name = "Dac")
public class Dac {
	
	
	@Id
	@Column(name="id")
	private int id;
	
	@Column(name="name")
	private String name;
	
	@Column(name="subject")
	private String subject;
	
	@Column(name="CCEE")
	private int CCEE;
	
	@Column(name="IA")
    private int IA;
	
	@Column(name="lab")
    private int lab;
	
	@Column(name="total")
    private int total;
    
	@Column(name="email")
	private String email;

    public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public int getCCEE() {
		return CCEE;
	}
	public void setCCEE(int cCEE) {
		CCEE = cCEE;
	}
	public int getIA() {
		return IA;
	}
	public void setIA(int iA) {
		IA = iA;
	}
	public int getLab() {
		return lab;
	}
	public void setLab(int lab) {
		this.lab = lab;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
    

        
		
	

}
