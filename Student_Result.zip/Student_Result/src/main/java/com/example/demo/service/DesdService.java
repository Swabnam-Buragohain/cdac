package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Desd;

public interface DesdService {

	public Desd saveStudent(Desd desd);
	
	public List<Desd> getAllStudent();

	public Desd getStudentById(Integer id);

	public String deleteStudent(Integer id);

	public Desd editStudent(Desd desd);
}
