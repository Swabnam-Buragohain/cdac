package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Dbda;
import com.example.demo.repository.DbdaRepo;
import com.example.demo.service.DbdaService;



@CrossOrigin("*")
@RestController
@RequestMapping("/Dbda")
public class DbdaController {

	
	@Autowired
	private DbdaService service;
	
	@Autowired
	DbdaRepo repo;

	@PostMapping("/saveStudent")
	public ResponseEntity<?> saveStudent(@RequestBody Dbda dbda) {
		return new ResponseEntity<>(service.saveStudent(dbda), HttpStatus.CREATED);
	}

	@GetMapping("/all")
	public ResponseEntity<?> getAllStudent() {
		return new ResponseEntity<>(service.getAllStudent(), HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<?> getStudentById(@PathVariable Integer id) {
		return new ResponseEntity<>(service.getStudentById(id), HttpStatus.OK);
	}

//	@GetMapping("/deleteProduct/{id}")
//	public ResponseEntity<?> deleteStudent(@PathVariable Integer id) {
//		return new ResponseEntity<>(service.deleteStudent(id), HttpStatus.OK);
//	}
	
	@DeleteMapping("delete/{id}")
	public ResponseEntity<?> deleteProduct(@PathVariable int id)
	{
		
		return new ResponseEntity<>(service.deleteStudent(id), HttpStatus.OK);
	}
	

	
	@PutMapping("update")
	public ResponseEntity<?>  editStudent(@RequestBody Dbda dbda)
	{
		return new ResponseEntity<>(service.editStudent(dbda), HttpStatus.CREATED);
		
	}
}
