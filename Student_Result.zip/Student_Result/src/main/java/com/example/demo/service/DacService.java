package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Dac;

public interface DacService {

	public Dac saveStudent(Dac dac);
	
	public List<Dac> getAllStudent();

	public Dac getStudentById(Integer id);

	public String deleteStudent(Integer id);

	public Dac editStudent(Dac dac);
}
