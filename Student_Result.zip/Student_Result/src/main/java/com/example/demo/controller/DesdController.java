package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Desd;
import com.example.demo.repository.DesdRepo;
import com.example.demo.service.DesdService;




@CrossOrigin("*")
@RequestMapping("/Desd")
@RestController
public class DesdController {

	
	@Autowired
	private DesdService service;
	
	@Autowired
	DesdRepo repo;

	@PostMapping("/saveStudent")
	public ResponseEntity<?> saveStudent(@RequestBody Desd desd) {
		return new ResponseEntity<>(service.saveStudent(desd), HttpStatus.CREATED);
	}

	@GetMapping("/all")
	public ResponseEntity<?> getAllStudent() {
		return new ResponseEntity<>(service.getAllStudent(), HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<?> getStudentById(@PathVariable Integer id) {
		return new ResponseEntity<>(service.getStudentById(id), HttpStatus.OK);
	}

//	@GetMapping("/deleteProduct/{id}")
//	public ResponseEntity<?> deleteStudent(@PathVariable Integer id) {
//		return new ResponseEntity<>(service.deleteStudent(id), HttpStatus.OK);
//	}
	
	@DeleteMapping("delete/{id}")
	public ResponseEntity<?> deleteProduct(@PathVariable int id)
	{
		
		return new ResponseEntity<>(service.deleteStudent(id), HttpStatus.OK);
	}
	

	
	@PutMapping("update")
	public ResponseEntity<?>  editStudent(@RequestBody Desd desd)
	{
		return new ResponseEntity<>(service.editStudent(desd), HttpStatus.CREATED);
		
	}
}
