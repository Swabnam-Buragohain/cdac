package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Dbda;
import com.example.demo.repository.DbdaRepo;

@Service
public class DbdaServiceImpl implements DbdaService {

	@Autowired
	private DbdaRepo repo;
	
	
	@Override
	public Dbda saveStudent(Dbda dbda) {
		return repo.save(dbda);
	}

	@Override
	public List<Dbda> getAllStudent() {		
		return repo.findAll();
}

	@Override
	public Dbda getStudentById(Integer id) {
		return repo.findById(id).get();

	}

	@Override
	public String deleteStudent(Integer id) {
		
			repo.deleteById(id);

		return (id +" is deleted successfully");
	}

	@Override
	public Dbda editStudent(Dbda dbda) {
		
		return repo.save(dbda);
	}

}
