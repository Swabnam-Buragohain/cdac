package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Dbda;

public interface DbdaService {

	public Dbda saveStudent(Dbda dbda);
	
	public List<Dbda> getAllStudent();

	public Dbda getStudentById(Integer id);

	public String deleteStudent(Integer id);

	public Dbda editStudent(Dbda dbda);
}
