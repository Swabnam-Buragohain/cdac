package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Dac;
import com.example.demo.repository.DacRepo;

@Service
public class DacServiceImpl implements DacService {

	@Autowired
	private DacRepo repo;
	
	
	@Override
	public Dac saveStudent(Dac dac) {
		return repo.save(dac);
	}

	@Override
	public List<Dac> getAllStudent() {		
		return repo.findAll();
}

	@Override
	public Dac getStudentById(Integer id) {
		return repo.findById(id).get();

	}

	@Override
	public String deleteStudent(Integer id) {
		
			repo.deleteById(id);

		return (id +" is deleted successfully");
	}

	@Override
	public Dac editStudent(Dac dac) {
		
		return repo.save(dac);
	}

}
